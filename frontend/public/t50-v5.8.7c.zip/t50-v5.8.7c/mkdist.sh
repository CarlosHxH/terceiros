#!/bin/bash

make dist
