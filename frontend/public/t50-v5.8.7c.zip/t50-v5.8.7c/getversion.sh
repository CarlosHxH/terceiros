#!/bin/bash

grep ^VERSION Makefile
